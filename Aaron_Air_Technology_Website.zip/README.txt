AARON AIR TECHNOLOGY WEBSITE
Files included:
- index.html: responsive company website
- aaron-logo.png: company logo
- industrial-fan.jpg: supplied product photo

Contact details included: aaronairtech20@gmail.com, +91 98437 32636, Chennai, Tamil Nadu, India.

To publish for free with GitHub Pages:
1. Sign in to GitHub and open your repository.
2. Upload all three files (index.html, aaron-logo.png, industrial-fan.jpg) to the repository root.
3. Open Settings > Pages.
4. Under Build and deployment, select Deploy from a branch, branch main, folder /(root), then Save.
5. GitHub will display the public website address once deployment finishes.

Please verify product descriptions before publishing.
